Assignment 5(Optional: for increasing marks in midsem)

prisma.py

Dependencies: Opencv, numpy

-The script adds the effect of source image on the target image using concepts from the
paper shared along with the assignment

-In main function (line:444), change source and target files to test

-2 implementations:
1.Basic: Without any clusters. Sample output files in "Most Basic Correction" folder
2.Advanced: Using clusters in source and target images, throughout the image. Sample output
in "Advanced Correction" folder

-How to run the script:
1.Basic: Comment out lines:514,515 and uncomment lines:512,513
2.Advanced: Comment out line:512,513 and uncomment lines:514,515